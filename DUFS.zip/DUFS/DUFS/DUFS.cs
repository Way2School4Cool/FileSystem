﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DUFS
{
	public class DUFS
	{

		private static FileStream m_file = null;
		private static DUFS m_fs = null;
		private static String dirName = null;

		private DUFS(String VolumeName)
		{
			m_file = new FileStream(VolumeName, FileMode.Open);
			dirName = VolumeName;
		}

		public static DUFS Mount(String VolumeName)
		{
			if (File.Exists(VolumeName))
				m_fs = new DUFS(VolumeName);

			return m_fs; 
		}

		public static Boolean Allocate(String VolumeName, int Size)
		{
			Boolean allocated = true;

			FileStream file = new FileStream(VolumeName, FileMode.Create);

			for (int i = 0; i < Size; i++)
			{
				file.WriteByte((byte)'\0');
			}

			file.Close();

			return allocated;
		}

		public static Boolean Deallocate(String VolumeName)
		{
			Boolean deallocated = true;

			if (File.Exists(VolumeName))
				File.Delete(VolumeName);

			return deallocated;
		}

		public static Boolean Truncate(String VolumeName)
		{
			Boolean truncated = true;

			if (File.Exists(VolumeName))
			{
				FileInfo fInfo = new FileInfo(VolumeName);
				FileStream file = new FileStream(VolumeName, FileMode.Open);

				for (long i = 0; i < fInfo.Length; i++)
				{
					file.WriteByte((byte)'\0');
				}

				file.Close();
			}
			else
				truncated = false;

			return truncated;
		}

		public static void Dump(String VolumeName)
		{
			if (File.Exists(VolumeName))
			{
				FileStream file = new FileStream(VolumeName, FileMode.Open);

				for (int i = 0; i < file.Length; i++)
				{
					Console.Write("{0}", file.ReadByte());
				}

				file.Close();
			}
		}

		public Boolean isMounted
		{
			get
			{
				return (m_fs != null); 
			}
		}

		//TODO: check that file initialization doesnt run off the end of the "directory"
		public Boolean Create( String FileName )
		{
			String expandedFileName = FileName;
			String fileStart = "";
			String fileSize = "00000000";
			String strDate = "";
			String strTime = "";
			String modDate;
			String modTime;
			String readOnly = "0";

			int writePos = -1;
			int timeSpace;
			String strDateTime;
			bool timeAM = true;
			DateTime dateTime = DateTime.Now;
			strDateTime = dateTime.ToString();
			String fileHeader;
			byte[] test = new byte[1];

			//check for open create spot (for x = start of file, to end of file, x =+ 64)
			//if NULL is found, start writting
			for (int x = 0; x < m_file.Length; x += 64)
			{
				m_file.Seek(x, SeekOrigin.Begin);
				m_file.Read(test, 0, 1);
				if(test[0] == 0)
				{
					writePos = x;
					break;
				}
			}

			if (writePos == -1)
			{
				return false;
			}

			fileStart = new string('0', 8 - (writePos.ToString().Length)) + writePos.ToString();
			Console.WriteLine(fileStart);

			
			if (FileName.Length > 23)
			{
				return false;
			}
			if (strDateTime[1] == '/') // (m/)
			{
				strDate = strDate + "0" + strDateTime[0];
				if (strDateTime[3] == '/') // (m/d/)
				{
					strDate = strDate + "0" + strDateTime[2] + strDateTime[4] + strDateTime[5] + strDateTime[6] + strDateTime[7];

				}
				else // (m/dd/)
				{
					strDate = strDate + strDateTime[2] + strDateTime[3] + strDateTime[5] + strDateTime[6] + strDateTime[7] + strDateTime[8];
				}
			}
			else // (mm/)
			{
				strDate += strDateTime[0] + strDateTime[1];
				if (strDateTime[4] == '/') //(mm/d/)
				{
					strDate = strDate + "0" + strDateTime[3] + strDateTime[5] + strDateTime[6] + strDateTime[7] + strDateTime[8];
				}
				else // (mm/dd/)
				{
					strDate = strDate + strDateTime[3] + strDateTime[4] + strDateTime[6] + strDateTime[7] + strDateTime[8] + strDateTime [9];
				}
			}
		   
			timeSpace = strDateTime.IndexOf(' ');
			if (strDateTime.Contains('P'))
			{
				timeAM = false;
			}
			
			if (strDateTime[timeSpace + 2] == ':') //(h:mm)
			{
				if (timeAM)
				{
					strTime = "0" + strDateTime[timeSpace + 1];
				}
				else
				{
					strTime = ToMil((char)strDateTime[timeSpace + 1], ':');
				}
				strTime = strTime + strDateTime[timeSpace + 3] + strDateTime[timeSpace + 4];
			}
			else //(hh:mm)
			{
				if (timeAM)
				{
					if (strDateTime[timeSpace + 1] == '2')
					{
						strTime = "00";
					}
					else
					{
						strTime = "1" + strDateTime[timeSpace + 1];
					}
				}
				else
				{
					strTime = ToMil((char)strDateTime[timeSpace + 1], (char)strDateTime[timeSpace + 2]);
				}
				strTime = strTime + strDateTime[timeSpace + 4] + strDateTime[timeSpace + 5];
			}

			modDate = strDate;
			modTime = strTime;

			while (expandedFileName.Length < 23)
			{
				expandedFileName += " ";
			}
			
			fileHeader = expandedFileName + fileStart + fileSize + strDate + strTime + modDate + modTime + readOnly;

			//Console.WriteLine(fileHeader);

			//write to file
			m_file.Close();
			m_file.Dispose();
			m_file = null;

			string dirContents = File.ReadAllText(dirName);
			//Console.WriteLine(dirContents);

			var aStringBuilder = new StringBuilder(dirContents);
			aStringBuilder.Remove(writePos, 64);
			aStringBuilder.Insert(writePos, fileHeader);
			dirContents = aStringBuilder.ToString();
			
			File.WriteAllText(dirName, dirContents);

			m_fs = new DUFS(dirName);

			return true;
		}

		public void Catalog() {
			m_file.Close();
			m_file.Dispose();
			m_file = null;
			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, 63).Contains("\0")) {
					break;
				}
				if (!aStringBuilder.ToString(x + 23, 40).Any(char.IsDigit)) {
					break;
				}
				Console.WriteLine(aStringBuilder.ToString(x, 23));
			}
			m_fs = new DUFS(dirName);
		}

		public void UnMount()
		{
			if (m_file != null)
			{
				m_file.Close();
				m_file.Dispose();
				m_file = null;

				m_fs = null; 
			}
		}

		public void DirInfo()
		{
			m_file.Close();
			m_file.Dispose();
			m_file = null;
			int nulls = 0;
			int files = 0;
			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			Console.WriteLine("Directory Length: " + aStringBuilder.Length);

			for (int x = 0; x < aStringBuilder.Length; x++) {
				if (aStringBuilder.ToString(x, 1).Contains("\0")) {
					nulls++;
				}
			}

			Console.WriteLine("Free Bytes: " + nulls);

			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, 63).Contains("\0")) {
					break;
				}
				if (!aStringBuilder.ToString(x + 23, 40).Any(char.IsDigit)) {
					break;
				}
				files++;
			}

			Console.WriteLine("Files: " + files);
			m_fs = new DUFS(dirName);
		}

		public bool Write(String fileName, int start, String writeData)
		{
			//write to file
			m_file.Close();
			m_file.Dispose();
			m_file = null;

			int writePos = -1;
			String fileStart;
			String fileSize;
			String headerInfo;

			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, fileName.Length) == fileName
					&& aStringBuilder.ToString(x + fileName.Length, 1) == " ") {
					
					writePos = x;
					break;
				}
			}

			if (writePos != -1) {
				//rewrite start and size info
				fileStart = new String('0', 8 - (start.ToString().Length)) + start.ToString();
				fileSize = new String('0', 8 - (writeData.Length.ToString().Length)) + writeData.Length.ToString();
				headerInfo = fileStart + fileSize;
			}
			else {
				m_fs = new DUFS(dirName);
				return false;
			}
			
			aStringBuilder.Remove(writePos + 23, 16);
			aStringBuilder.Insert(writePos + 23, headerInfo);
			
			//TODO: make sure data isnt already present

			//TODO: Update the modified time

			//if(data exits from start to (start + data.length))
			
			aStringBuilder.Remove(start, writeData.Length);
			aStringBuilder.Insert(start, writeData);
			
			dirContents = aStringBuilder.ToString();

			File.WriteAllText(dirName, dirContents);

			m_fs = new DUFS(dirName);
			
			//return true if file was created properly
			return true;
		}

		public void Read(String fileName, int start, int end)
		{
			//TODO: Validate end > start

			m_file.Close();
			m_file.Dispose();
			m_file = null;
			byte[] test = new byte[1];
			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			//TODO: Validate start and end are within the file constraints
			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, fileName.Length) == fileName
					&& aStringBuilder.ToString(x + fileName.Length, 1) == " ") {

					int readPosition = int.Parse(aStringBuilder.ToString(x + 23, 8));
					Console.WriteLine("read pos: " + readPosition);
					Console.WriteLine(aStringBuilder.ToString(readPosition + start, end - start));

					break;
				}
			}
			m_fs = new DUFS(dirName);
		}

		public bool Delete(String fileName)
		{
			//TODO
			m_file.Close();
			m_file.Dispose();
			m_file = null;
			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, fileName.Length) == fileName
					&& aStringBuilder.ToString(x + fileName.Length, 1) == " ") {

					int readPosition = int.Parse(aStringBuilder.ToString(x + 23, 8));
					int fileSize = int.Parse(aStringBuilder.ToString(x + 32, 8));

					String nullData = new string('\0', fileSize);
					String nullHeaderData = new string('\0', 64);

					aStringBuilder.Remove(readPosition, fileSize);
					aStringBuilder.Insert(readPosition, nullData);

					aStringBuilder.Remove(x, 64);
					aStringBuilder.Insert(readPosition, nullHeaderData);

					//if successfully deleted
					dirContents = aStringBuilder.ToString();

					File.WriteAllText(dirName, dirContents);
					m_fs = new DUFS(dirName);
					return true;

				}
			}
			m_fs = new DUFS(dirName);
			return false;
		}

		public bool FileTruncate(String fileName)
		{
			Delete(fileName);
			Create(fileName);

			//if successfully deleted
			return true;
		}

		public bool Info(String fileName)
		{
			m_file.Close();
			m_file.Dispose();
			m_file = null;
			byte[] test = new byte[1];
			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			//TODO: Validate start and end are within the file constraints
			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, fileName.Length) == fileName
					&& aStringBuilder.ToString(x + fileName.Length, 1) == " ") {

					String name = aStringBuilder.ToString(x, 23);
					String startPos = aStringBuilder.ToString(x + 23, 8);
					String sizePos = aStringBuilder.ToString(x + 31, 8);
					String createDate = aStringBuilder.ToString(x + 39, 8);
					String createTime = aStringBuilder.ToString(x + 47, 4);
					String modDate = aStringBuilder.ToString(x + 51, 8);
					String modTime = aStringBuilder.ToString(x + 59, 4);
					String readOnly = aStringBuilder.ToString(x + 63, 1);

					if (readOnly == "0") {
						readOnly = "False";
					}
					else {
						readOnly = "True";
					}

					Console.WriteLine("Name: " + name);
					Console.WriteLine("File Start: " + startPos);
					Console.WriteLine("File Size: " + sizePos);
					Console.WriteLine("Create Date: " + createDate[0] + createDate[1] + "/" + createDate[2] + createDate[3] + "/" + createDate[6] + createDate[7]);
					Console.WriteLine("Create Time: " + createTime[0] + createTime[1] + ":" + createTime[2] + createTime[3]);
					Console.WriteLine("Modified Date: " + modDate[0] + modDate[1] + "/" + modDate[2] + modDate[3] + "/" + modDate[6] + modDate[7]);
					Console.WriteLine("Modified Time: " + modTime[0] + modTime[1] + ":" + modTime[2] + modTime[3]);
					Console.WriteLine("Read Only: " + readOnly);

					m_fs = new DUFS(dirName);

					return true;
				}
			}
			m_fs = new DUFS(dirName);

			return false;			
		}

		public bool Set(String fileName, bool readOnlyStatus)
		{

			m_file.Close();
			m_file.Dispose();
			m_file = null;
			byte[] test = new byte[1];
			string dirContents = File.ReadAllText(dirName);
			var aStringBuilder = new StringBuilder(dirContents);

			for (int x = 0; x < aStringBuilder.Length; x += 64) {
				if (aStringBuilder.ToString(x, fileName.Length) == fileName
					&& aStringBuilder.ToString(x + fileName.Length, 1) == " ") {

					aStringBuilder.Remove(x + 63, 1);
					if (readOnlyStatus) {
						aStringBuilder.Insert(x + 63, "1");
					}
					else {
						aStringBuilder.Insert(x + 63, "0");
					}

					dirContents = aStringBuilder.ToString();

					File.WriteAllText(dirName, dirContents);

					m_fs = new DUFS(dirName);

					//if successfully changed
					return true;

				}
			}
			m_fs = new DUFS(dirName);

			return false;
		}

		public static String ToMil(char time1, char time2)
		{
			String milTime = "er";


			if (time2 == ':') {
				switch (time1)
				{
					case '1':
						milTime = "13";
						break;
					case '2':
						milTime = "14";
						break;
					case '3':
						milTime = "15";
						break;
					case '4':
						milTime = "16";
						break;
					case '5':
						milTime = "17";
						break;
					case '6':
						milTime = "18";
						break;
					case '7':
						milTime = "19";
						break;
					case '8':
						milTime = "20";
						break;
					case '9':
						milTime = "21";
						break;
				}
			}
			else
			{
				switch (time2)
				{
					case '0':
						milTime = "22";
						break;
					case '1':
						milTime = "23";
						break;
					case '2':
						milTime = "12";
						break;
				}
			}
						
			return milTime;
		}
	}
}
