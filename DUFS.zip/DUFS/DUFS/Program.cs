﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace DUFS
{
	public class Program
	{
		public const int COMMAND_NAME = 0;
		// ALLOCATION
		public const int CMD_ALLOC_VOLNAME = 1;
		public const int CMD_ALLOC_SIZE = 2;
		// DEALLOCATION
		public const int CMD_DEALLOC_VOLNAME = 1;
		// TRUNCATE
		public const int CMD_TRUNC_VOLNAME = 1;
		// DUMP
		public const int CMD_DUMP_VOLNAME = 1;
		// MOUNT
		public const int CMD_MOUNT_VOLNAME = 1;
		// UNMOUNT
		// NO ARGUMENTS FOR UNMOUNT

		public static Boolean isMounted = false;
		public static String volumeName = String.Empty;
		public static String Command = String.Empty;
		static void Main(string[] args)
		{
			DUFS dufs;

			if (args.Length == 0)
			{
				Console.WriteLine("Invalid arguments");
				return;
			}

			Command = args[COMMAND_NAME];

			//
			// ALLOCATE <VOLUMENAME> <SIZE>
			//
			if (Command.Equals("ALLOCATE"))
			{
				if (args.Length != 3)
				{
					Console.WriteLine("Invalid number of arguments for the ALLOCATE command.");
					return;
				}

				String VolumeName = args[CMD_ALLOC_VOLNAME];
				String Size = args[CMD_ALLOC_SIZE];

				DUFS.Allocate(VolumeName, int.Parse(Size));
			}
			else if (Command.Equals("DEALLOCATE"))
			{
				if (args.Length != 2)
				{
					Console.WriteLine("Invalid number of arguments for the DEALLOCATE command.");
					return;
				}

				String VolumeName = args[CMD_DEALLOC_VOLNAME];
				DUFS.Deallocate(VolumeName);
			}
			else if (Command.Equals("TRUNCATE"))
			{
				if (args.Length != 2)
				{
					Console.WriteLine("Invalid number of arguments for the TRUNCATE command.");
					return;
				}

				String VolumeName = args[CMD_TRUNC_VOLNAME];
				DUFS.Truncate(VolumeName);
			}
			else if (Command.Equals("DUMP"))
			{
				if (args.Length != 2)
				{
					Console.WriteLine("Invalid number of arguments for the DUMP command.");
					return;
				}

				String VolumeName = args[CMD_DUMP_VOLNAME];
				DUFS.Dump(VolumeName);
			}
			else if (Command.Equals("MOUNT"))
			{
				if (args.Length != 2)
				{
					Console.WriteLine("Invalid number of arguments for the MOUNT command.");
					return;
				}

				if (isMounted)
				{
					Console.WriteLine("Volume '{0}' is already mounted.  Unmount it before mounting another volume.", volumeName);
					return;
				}

				String VolumeName = args[CMD_MOUNT_VOLNAME];
				dufs = DUFS.Mount(VolumeName);

				if (dufs != null)
				{
					String FileName = String.Empty;
					String[] writeList;
					String writeData = "";
					Boolean success = false;
					int startPosition = -1;
					int endPosition = -1;
					Console.WriteLine("Volume '{0}' is mounted.", VolumeName);
					while (dufs.isMounted)
					{

						Console.Write("DUFS:>");
						Command = Console.ReadLine();

						if (Command.StartsWith("CREATE", StringComparison.OrdinalIgnoreCase)) {
							//CREATE FILENAME
							Command = Command.Trim();
							FileName = Command.Split(' ')[1];

							success = dufs.Create(FileName);

							if (success)
								Console.WriteLine("File Created!");
							else
								Console.WriteLine("The File Was Not Created!  TO DO: Provide Error Messages!");
						}
						else if (Command.StartsWith("WRITE", StringComparison.OrdinalIgnoreCase)) {
							//Write to FILENAME
							Command = Command.Trim();
							FileName = Command.Split(' ')[1];
							startPosition = int.Parse(Command.Split(' ')[2]);
							
							writeList = Command.Split(' ');
							
							for (int x = 3; x < writeList.Length; x++) {
								writeData += writeList[x] + " ";
							}
							writeData = writeData.Remove(writeData.Length - 1, 1);

							success = dufs.Write(FileName, startPosition, writeData);

							if (!success)
								Console.WriteLine("An error has occured");
						}
						else if (Command.StartsWith("READ", StringComparison.OrdinalIgnoreCase)) {
							Command = Command.Trim();
							FileName = Command.Split(' ')[1];
							startPosition = int.Parse(Command.Split(' ')[2]);
							endPosition = int.Parse(Command.Split(' ')[3]);

							dufs.Read(FileName, startPosition, endPosition);
						}
						else if (Command.StartsWith("DELETE", StringComparison.OrdinalIgnoreCase)) {
							Command = Command.Trim();
							FileName = Command.Split(' ')[1];

							bool deletion = dufs.Delete(FileName);
							if (deletion) {
								Console.WriteLine("Deleted");
							}
							else {
								Console.WriteLine("Error");
							}
						}
						else if (Command.StartsWith("TRUNCATE", StringComparison.OrdinalIgnoreCase)) {
							Command = Command.Trim();
							FileName = Command.Split(' ')[1];

							bool Truncated = dufs.FileTruncate(FileName);

							if (Truncated) {
								Console.WriteLine("Truncated");
							}
							else {
								Console.WriteLine("Error");
							}
						}

						else if (Command.StartsWith("Info", StringComparison.OrdinalIgnoreCase)) {
							Command = Command.Trim();
							FileName = Command.Split(' ')[1];

							bool Info = dufs.Info(FileName);

							if (!Info) {
								Console.WriteLine("Error");
							}
						}

						else if (Command.StartsWith("EXIT", StringComparison.OrdinalIgnoreCase)) {
							dufs.UnMount();
						}
					}
				}
			}
		}
	}
}
